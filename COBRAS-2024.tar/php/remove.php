<?php
$dir='/home/travis.wilson/public_html/COBRAS/data/20';
system("rm -rf ".escapeshellarg($dir)."*");
?>
