#!/usr/bin/python
import sys
folder=sys.argv[1]

from time import sleep


print "test2",folder
sleep(1)
print "test2_again"


