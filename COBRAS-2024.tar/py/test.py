import sys,os
from datetime import datetime, timedelta
from shutil import copyfile


copyfile('/var/www/PSR/COBRAS/py/test.py','/var/www/PSR/COBRAS/py/test.py.copy')

